/*
 * slaver.cpp
 *
 *  Created on: 2013-4-1
 *      Author: root
 */

#include "slaver.h"

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <arpa/inet.h>

#include<fcntl.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>

#include <unistd.h>
//#include "utility.h"
#include <sstream>
#include <string>
#include <iostream>


#include "GlobalHelper.h"


#define DEBUG
#define DEBUG_GRAB
#define BUFSIZE 1449
#define READ_BUFF_SIZE 1448
namespace poseidon {

slaver::~slaver() {

}

bool slaver::requestTask(task *mytask, string& str_cmd) {
	//1 init variable
	int socketfd;
	struct sockaddr_in dest_addr;
	char read_buf[BUFSIZE];
	bzero(&read_buf, sizeof read_buf);
	bool req_seccess = 0;
	while (1) {
		//2 create socket
		if ((socketfd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
			gh->log("socket fd create fail..."); //perror("socket fd create fail...");
			break;
		}

		//3 prepare server address
		this->init_address(&dest_addr, PF_INET, this->master_port,
				this->master_ip[0]);

		//4 connect to server
		if (-1
				== connect(socketfd, (struct sockaddr*) &dest_addr,
						sizeof(struct sockaddr))) {
			printf("socket fd connet fail..."); //perror("socket fd connet fail...");
			break;
		}

		gh->log(
				string(
						"connect to " + this->master_ip[0] + ":"
								+ gh->num2str(this->master_port)));

		//5 talk with server
		int bytes_count;
		//	while (1) { //loop if request failed		//prepare_req_cmd();
		prepare_req_cmd();
		int write_result = write(socketfd, this->cmd_req_2send.c_str(),
				strlen(this->cmd_req_2send.c_str()));
		if (write_result < 0) {
			gh->log("socket fd write fail..."); //perror
			break; //continue;
		}

		cout << "write:" << this->cmd_req_2send << endl;
		while ((bytes_count = read(socketfd, read_buf, READ_BUFF_SIZE)) > 0) {
			if (bytes_count == 0) {
				gh->log("socket fd read fail..."); //perror
				break;
			}

			if (gh->tail_with_feature(read_buf, bytes_count, "\f")) {
				break;
			}
			read_buf[bytes_count] = '\0';
		}
		req_seccess = 1;
		break;
	}
	//}
	//6 clear socket
	close(socketfd);
	//7  init task
#ifdef DEBUG
//	cout << "receive:" << read_buf << endl;
#endif
	str_cmd = read_buf;
//	gh->log(str_cmd);
	return req_seccess;
//cout << "cmd_id:" << (*mytask).cmd_id << endl;
	//cout << "slave_id:" << (*mytask).response_cmd_map["slave_id"] << endl;
//	cout << "version" << (*mytask).response_cmd_map["version"] << endl;

}

bool slaver::grabpage_work(task& mytask) {
	string dest_ip;

	this->last_task_status = 0;
	uint count = mytask.urls_http_req.size();
	for (vector<string>::size_type index = 0; index < count; index++) {

		if (lookup_ip(mytask.urls_sites.at(index), dest_ip)) {
			grabtask gt;
			gt.http_req = mytask.urls_http_req.at(index);
			gt.request_ip = dest_ip;
			gt.request_port = 80;
			gt.index = index;
			gt.task_id = mytask.task_id.at(0);
			gt.url = mytask.urls_vec.at(index);

			grab_page_log_time(gt);

			//grab_page_log_time(dest_ip, 80, index,
			//	mytask.urls_http_req.at(index), mytask.task_id.at(0));
			//grab_page
		}

	}
	return 1;
}
//ip:port,http_req,index
bool slaver::grab_page(grabtask gt) {

	string http_req = gt.http_req; //= mytask.urls_http_req.at(index);
	string request_ip = gt.request_ip;
	int request_port = gt.request_port;
	int task_index = gt.index;
	string task_id = gt.task_id; // = mytask.task_id.at(0);
	string url = gt.url; //mytask.urls.at(index);

#ifdef DEBUG //#define DEBUG_GRAB
	cout << "grab index:" << task_index << ";" << request_ip << ":"
			<< request_port << endl;
	gh->log(http_req);
	//	<< ";" << "http_req:\n" << http_req
#endif
	struct sockaddr_in dest_addr;

	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (-1 == sockfd) {
		perror("socket fd create fail...");
		return -1;
	}

	gh->init_address(&dest_addr, AF_INET, request_port,
			inet_addr(request_ip.c_str()));

	if (-1
			== connect(sockfd, (struct sockaddr*) &dest_addr,
					sizeof(struct sockaddr))) {
		perror("socket fd connet fail...");
		return -1;
	}

	if (-1 == write(sockfd, http_req.c_str(), http_req.size())) {
		perror("socket fd write fail...");
		gh->log2("socket fd write fail...", "SOCKET");
		return -1;
	}
	char buf[4096];
	int count = 0;
	string response_content;

	//========================================
	//open grab_page_file and write split_str into it
	//========================================
	string filename = gh->grab_page_filename(task_index, task_id);
	int fd = open(filename.c_str(), O_CREAT | O_WRONLY | O_APPEND);
	string split_s1 = gh->get_str_betwen_pages(gt.url);
	write(fd, split_s1.c_str(), split_s1.size());

#ifdef DEBUG
	cout << "wait to reading from socket:" << endl;
#endif

	while ((count = read(sockfd, buf, READ_BUFF_SIZE)) > 0) {
		if (count == -1) {
			gh->log("socket fd read faild...");
			break;
		}
		if (count == 0) {
			gh->log("socket fd read end...");
			break;
		}
		write(fd, buf, count);
		//	if (gh->is_html_end(buf, count)) {
		//		break;
		//		}
	}
//append '\a' between different pages

	this->last_task_status = 1; //

	close(fd);

	close(sockfd);

	//尝试通过C＋＋函数写入本地文件，内容缺失，，猜测是STR.APPEND的时候加入了‘、0’
	//string filename2 = "./txt_" + gh->num2str(index) + ".txt";
	//TextLogger *logger = new TextLogger(filename2.c_str());
	//logger->LogContent(response_content);

	printf("Socket close!\n");

	return 0;
}

bool slaver::remoteStorePage(storetask s_task, string send_cmd,
		string send_filename) {

	string request_ip = s_task.request_ip;
	int request_port = s_task.request_port;
	//==============================
	//1.init var and connect to rep
	//==============================
	gh->log("connect to:" + request_ip + ":" + gh->num2str(request_port));
	struct sockaddr_in dest_addr;

	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (-1 == sockfd) {
		perror("socket fd create fail...");
		return -1;
	}

	gh->init_address(&dest_addr, AF_INET, request_port,
			inet_addr(request_ip.c_str()));

	if (-1
			== connect(sockfd, (struct sockaddr*) &dest_addr,
					sizeof(struct sockaddr))) {
		perror("socket fd connet fail...");
		return false;
	}
	//==============================
	//2.write cmd to rep
	//==============================
	//[001]read binary page and prepare send. begin
	ifstream is_page(send_filename.c_str(), ios::binary);
	char * page_buff;
	if (!is_page) {
		return false;
	}
	is_page.seekg(0, is_page.end);
	size_t length = is_page.tellg();
	is_page.seekg(0, is_page.beg);
	page_buff = (char *) malloc(length);
	is_page.read(page_buff, length);

	//[001]read binary page and prepare send. end
	send_cmd = gh->replace(send_cmd, gh->size_t2str(length), "#");
	gh->log(send_cmd);
	if (-1 == write(sockfd, send_cmd.c_str(), send_cmd.size())) {
		gh->log(" 2.write cmd to rep , write error ! ");
		//break; //simple lose
		return false;
	}

	//==============================
	//3.revice message
	//==============================
	int count = 0;
	string response_content;
	char buf[1449];
	while ((count = read(sockfd, buf, READ_BUFF_SIZE)) > 0) {
		buf[count] = '\0';
		cout << "3.revice message buf :" << buf << endl;
		if (count == 0) {
			break;
		}
		if (count < 0) {
			gh->log("read error");
			break;
		}
		if (gh->tail_with_feature(buf, count, "\f")) {
			break;
		}
	}

	//==============================
	//4.prepare send content
	//==============================
	cout << "4.prepare send content:*\n" << page_buff << "*" << endl;
	//write
	if (-1 == write(sockfd, page_buff, length)) {
		//break; //simple lose
		perror("4.prepare send content:write error. ");
		return false;
	}
	free(page_buff);
	//}
	try {
		is_page.close();

		close(sockfd);
	} catch (std::exception& e) {
		gh->log(e.what());
	}
	printf("Socket close!\n");

	return 0;
}
/*
 string slaver::getHttpHeader(string url_header, vector<string> url_body,
 int id) {
 //url_header.replace(url_header.find_first_of('#'),,url_body);

 string::size_type pos(0);

 const string special_char = "#";
 const string s4 = url_body.at(id);

 pos = url_header.find_first_of('#');
 //	if ((pos = url_header.find(special_char)) != string::npos)

 url_header = url_header.replace(pos, 1, "");
 return url_header.insert(pos, s4);

 }*/

} /* namespace poseidon */
