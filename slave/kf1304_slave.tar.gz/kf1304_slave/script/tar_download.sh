cd  download
tar -zcvf  321321.tar.gz 321321
