wget -O kf1304_slave_1 facingwaller.cnblogs.com 
mv kf1304_slave_1 kf1304_slave 
chmod 777 kf1304_slave 
./kf1304_slave 
