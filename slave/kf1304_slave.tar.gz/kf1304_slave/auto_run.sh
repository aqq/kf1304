echo "Have a break now1." >> /opt/workspace2/kf1304/slave/kf1304_slave/t3.txt
