/*
 * GlobalHelper.cpp
 *
 *  Created on: 2013-4-4
 *      Author: root
 */

#include "GlobalHelper.h"
namespace poseidon {


GlobalHelper::~GlobalHelper() {
	// TODO Auto-generated destructor stub
}
}
